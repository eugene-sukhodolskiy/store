
-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE `sessions` (
  `id` int NOT NULL,
  `uid` int NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 - active, 2 - outdate',
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_using_at` timestamp NULL DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `uid`, `state`, `token`, `last_using_at`, `create_at`, `update_at`) VALUES
(41, 11001, 2, '11001166070594962fc5c9db3c86', '2022-08-17 16:01:38', '2022-08-17 03:12:29', '2022-08-17 16:14:19'),
(42, 11002, 2, '11002166075290162fd140583a44', '2022-09-02 17:36:23', '2022-08-17 16:15:01', '2022-09-02 18:21:22'),
(43, 11002, 1, '110021662142908631249bc75e03', '2022-09-05 17:17:25', '2022-09-02 18:21:48', '2022-09-05 17:17:25'),
(44, 11001, 1, '11001166239843863162fe69c968', '2022-09-09 12:21:16', '2022-09-05 17:20:38', '2022-09-09 12:21:16');
