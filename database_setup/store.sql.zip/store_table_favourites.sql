
-- --------------------------------------------------------

--
-- Структура таблицы `favourites`
--

CREATE TABLE IF NOT EXISTS `favourites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `ent_id` int NOT NULL,
  `assignment` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `favourites`
--

INSERT INTO `favourites` (`id`, `uid`, `ent_id`, `assignment`, `create_at`, `update_at`) VALUES
(3, 11002, 100003, 'UAdPost', '2022-09-01 13:34:49', '2022-09-01 13:34:49'),
(8, 11002, 100012, 'UAdPost', '2022-09-01 23:09:03', '2022-09-01 23:09:03'),
(9, 11002, 100002, 'UAdPost', '2022-09-01 23:17:17', '2022-09-01 23:17:17');
