
-- --------------------------------------------------------

--
-- Структура таблицы `meta`
--

CREATE TABLE IF NOT EXISTS `meta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ent_id` int NOT NULL,
  `assignment` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `value` text COLLATE utf8mb4_general_ci NOT NULL,
  `create_at` timestamp NULL DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `meta`
--

INSERT INTO `meta` (`id`, `ent_id`, `assignment`, `name`, `value`, `create_at`, `update_at`) VALUES
(1, 11002, 'User', 'total_published_uadposts', '2', '2022-08-23 14:24:09', '2022-09-05 15:56:36'),
(2, 11002, 'User', 'total_saled', '0', '2022-08-23 14:29:57', '2022-08-23 14:29:57'),
(3, 11001, 'User', 'total_published_uadposts', '0', '2022-08-23 20:47:51', '2022-08-23 20:47:51'),
(4, 11001, 'User', 'total_saled', '0', '2022-08-23 20:47:51', '2022-08-23 20:47:51'),
(5, 6085, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(6, 6085, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(7, 7489, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(8, 7489, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(9, 9568, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(10, 9568, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(11, 812, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(12, 812, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(13, 2945, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(14, 2945, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(15, 4091, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(16, 4091, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(17, 246, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(18, 246, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(19, 7076, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(20, 7076, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(21, 3354, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(22, 3354, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(23, 172, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(24, 172, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(25, 9741, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(26, 9741, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(27, 3305, 'User', 'total_published_uadposts', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(28, 3305, 'User', 'total_saled', '0', '2022-08-25 12:09:27', '2022-08-25 12:09:27'),
(29, 4451, 'User', 'total_published_uadposts', '0', '2022-08-25 12:10:21', '2022-08-25 12:10:21'),
(30, 4451, 'User', 'total_saled', '0', '2022-08-25 12:10:21', '2022-08-25 12:10:21'),
(31, 2705, 'User', 'total_published_uadposts', '0', '2022-08-25 12:10:34', '2022-08-25 12:10:34'),
(32, 2705, 'User', 'total_saled', '0', '2022-08-25 12:10:34', '2022-08-25 12:10:34'),
(33, 1333, 'User', 'total_published_uadposts', '0', '2022-08-25 12:11:14', '2022-08-25 12:11:14'),
(34, 1333, 'User', 'total_saled', '0', '2022-08-25 12:11:14', '2022-08-25 12:11:14'),
(35, 8489, 'User', 'total_published_uadposts', '0', '2022-08-25 12:11:42', '2022-08-25 12:11:42'),
(36, 8489, 'User', 'total_saled', '0', '2022-08-25 12:11:43', '2022-08-25 12:11:43'),
(37, 3685, 'User', 'total_published_uadposts', '0', '2022-08-25 12:11:49', '2022-08-25 12:11:49'),
(38, 3685, 'User', 'total_saled', '0', '2022-08-25 12:11:49', '2022-08-25 12:11:49');
